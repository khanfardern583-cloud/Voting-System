<!DOCTYPE html>
<html>
<head>
    <title>Election Commission of India</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="overlay">

<header>
    <div style="display:flex;align-items:center;gap:15px;">
        <img src="assets/emblem.jpg">
        <div>
            <h1>Election Commission of India</h1>
            <p>भारत निर्वाचन आयोग</p>
        </div>
    </div>

    <nav>
        <a href="index.php">Home</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="result.php">Results</a>
    </nav>
</header>

<section class="hero">
    <h2>Online Voting Portal</h2>

    <p>
        Secure • Transparent • Digital Democracy
    </p>

    <h3 class="live">
        LIVE NATIONAL ELECTION 2026
    </h3>

    <br><br>

    <a class="btn" href="register.php">New Voter Registration</a>

    <br><br><br>

    <div id="liveTime" style="font-size:25px;"></div>
</section>

<footer>
    © Government of India | Election Commission Portal
</footer>

</div>

<script src="script.js"></script>

</body>
</html>