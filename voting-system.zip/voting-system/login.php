<?php
session_start();

$message = "";

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $users = json_decode(file_get_contents('users.json'), true);

    foreach($users as $user){

        if($user['email']==$email && $user['password']==$password){

            $_SESSION['user']=$email;

            header("Location: vote.php");
            exit();
        }
    }

    $message = "Invalid Login Details";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="overlay">

<div class="container">

<h2>Secure Voter Login</h2>

<form method="POST">

<input type="email" name="email" placeholder="Email" required>

<input type="password" name="password" placeholder="Password" required>

<button name="login">Login</button>

</form>

<br>

<p style="text-align:center;color:red;">
<?php echo $message; ?>
</p>

</div>

</div>

</body>
</html>