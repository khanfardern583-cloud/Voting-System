<?php

$message = "";

if(isset($_POST['register'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $users = json_decode(file_get_contents('users.json'), true);

    foreach($users as $user){
        if($user['email'] == $email){
            $message = "User already exists";
        }
    }

    if($message == ""){

        $users[] = [
            'name'=>$name,
            'email'=>$email,
            'password'=>$password,
            'voted'=>false
        ];

        file_put_contents('users.json', json_encode($users, JSON_PRETTY_PRINT));

        $message = "Registration Successful";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="overlay">

<div class="container">

<h2>Voter Registration</h2>

<form method="POST">

<input type="text" name="name" placeholder="Full Name" required>

<input type="email" name="email" placeholder="Email Address" required>

<input type="password" name="password" placeholder="Password" required>

<button name="register">Register Now</button>

</form>

<br>

<p style="text-align:center; color:yellow;">
<?php echo $message; ?>
</p>

<br>

<p style="text-align:center;">
Already registered?
<a href="login.php" style="color:cyan;">Login</a>
</p>

</div>

</div>

</body>
</html>