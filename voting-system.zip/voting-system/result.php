<?php
$votes = json_decode(file_get_contents('votes.json'), true);

$results = [
    'BJP' => 0,
    'Congress' => 0,
    'TMC' => 0,
    'AAP' => 0
];

foreach($votes as $vote){

if(isset($results[$vote['party']])){
        $results[$vote['party']++] = $results[$vote['party']];
    }
}

foreach($votes as $vote){
  $results[$vote['party']]++;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Election Results</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

<h2>Live Election Results</h2>

<?php
foreach($results as $party => $count){
?>

<div class="result-box">
    <h3><?php echo $party; ?></h3>
    <p>Total Votes: <?php echo $count; ?></p>
</div>

<?php
}
?>

<a href="index.php" class="btn">Back To Home</a>

</div>

</body>
</html>