setInterval(()=>{
    const live = document.getElementById('liveTime');

    if(live){
        const now = new Date();
        live.innerHTML = now.toLocaleString();
    }
},1000);