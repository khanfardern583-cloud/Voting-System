<?php
include 'session_check.php';

$email = $_SESSION['user'];

$users = json_decode(file_get_contents('users.json'), true);

$message = "";

foreach($users as $index=>$user){

    if($user['email']==$email){

        if($user['voted']==true){
            $message = "You have already voted";
        }

        if(isset($_POST['vote']) && $user['voted']==false){
            
            $party = $_POST['party'];

            $votes = json_decode(file_get_contents('votes.json'), true);

            $votes[$party] += 1;

            file_put_contents('votes.json', json_encode($votes, JSON_PRETTY_PRINT));

            $users[$index]['voted'] = true;

            file_put_contents('users.json', json_encode($users, JSON_PRETTY_PRINT));

            $message = "Vote Submitted Successfully";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vote Now</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="overlay">

<header>
    <h1>National Voting Dashboard</h1>

    <nav>
        <a href="result.php">Live Results</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<h2 style="text-align:center;padding-top:30px;">
Cast Your Vote
</h2>

<p style="text-align:center;color:yellow;font-size:22px;">
<?php echo $message; ?>
</p>

<div class="party-grid">

<form method="POST" class="party-card">
    <img src="assets/bjp.png">
    <h2>BJP</h2>
    <input type="hidden" name="party" value="BJP">
    <button class="vote-btn" name="vote">Vote</button>
</form>

<form method="POST" class="party-card">
    <img src="assets/congress.webp">
    <h2>Congress</h2>
    <input type="hidden" name="party" value="Congress">
    <button class="vote-btn" name="vote">Vote</button>
</form>

<form method="POST" class="party-card">
    <img src="assets/TMC.png">
    <h2>TMC</h2>
    <input type="hidden" name="party" value="TMC">
    <button class="vote-btn" name="vote">Vote</button>
</form>

<form method="POST" class="party-card">
    <img src="assets/aap.jpg">
    <h2>AAP</h2>
    <input type="hidden" name="party" value="AAP">
    <button class="vote-btn" name="vote">Vote</button>
</form>

<form method="POST" class="party-card">
    <img src="assets/cpi-m.png">
    <h2>CPI-M</h2>
    <input type="hidden" name="party" value="CPM">
    <button class="vote-btn" name="vote">Vote</button>
</form>

<form method="POST" class="party-card">
    <img src="assets/bsp.webp">
    <h2>BSP</h2>
    <input type="hidden" name="party" value="BSP">
    <button class="vote-btn" name="vote">Vote</button>
</form>

</div>

</div>

</body>
</html>